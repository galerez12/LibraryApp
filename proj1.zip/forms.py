from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, IntegerField, \
    validators, SelectField, RadioField  # Importing a string forms
from wtforms_sqlalchemy.fields import QueryRadioField
from wtforms.validators import DataRequired, Length, Email, EqualTo  # Importing validators for fields


# Writing python classes that represent forms and will automatically be converted to html forms within our template.
# A class for a registration form.
class RegistrationForm(FlaskForm):
    # StringField - a form class of string type.
    # Validators is a list of things we want to validate in our form.
    # DataRequired() - validator, meaning that the field can't be empty, Length-determine the string length.
    id = IntegerField('ID', validators=[DataRequired(), validators.NumberRange(min=1, max=9999999999)])
    # Email() - an email validator.
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    # PasswordField - a form class of password type.
    password = PasswordField('Password', validators=[DataRequired(), Length(max=60)])
    # EqualTo - a validator that check equality to other field.
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    firstName = StringField('First Name', validators=[DataRequired(), Length(max=30)])
    lastName = StringField('Last Name', validators=[DataRequired(), Length(max=30)])
    # SubmitField - a form class of submit type.
    submit = SubmitField('Sign Up')


# A class for a Login form.
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    # BooleanField - a form class of boolean type.
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class SearchForm(FlaskForm):
    keyword = StringField('Search', validators=[DataRequired()])
    search_by = SelectField('Search By', choices=[('book', 'Book'), ('author', 'Author'), ('library', 'Library')],
                            render_kw={'style': 'width: 9ch'})
    submit = SubmitField('Submit')








