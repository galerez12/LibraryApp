from flask import Flask
app = Flask(__name__)  # this command initialize 'app' and telling
# flask where to look for things like templates, static files, etc.


# Decorators are a way to add more functionalities to existing function.
# The mark "/" is the root page of the website.
@app.route("/")
@app.route("/home")  # It is possible to add multiple decorators for one function.
def home():
    return "<h1>Home Page</h1>"


# To see this you need to go to 'localhost:5000/about'
@app.route("/about")
def about():
    return "<h1>About Page</h1>"


# Setting for app to look in this main code and running flask with debug mode.
# Debug mode means that changes will appear automatically instead of closing and
# running flask in terminal each time you update something.
# In other words, instead of writing "flask run" each time you can just
# refresh the website and see the changes.
if __name__ == '__main__':
    app.run(debug=True)