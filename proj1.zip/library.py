# To use templates we are importing render_templates
from flask import Flask, render_template, url_for, flash, redirect
from forms import RegistrationForm, LoginForm, SearchForm
from flask_sqlalchemy import SQLAlchemy
from models import Member, Library, Membership, Genre, Book, LoanedBook, BookInLibrary, db, app, RegisterToLibraryForm
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required , current_user

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog post 1',
        'content': 'First post content',
        'date_posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog post 2',
        'content': 'Second post content',
        'date_posted': 'April 21, 2018'
    }
]


@app.route("/")
@app.route("/home")
def home():
    # Instead of putting all the html code in the py file,
    # we can call any template with this command.
    # posts - passing argument with posts data to have access in the template
    return render_template('home.html', posts=posts)


@app.route("/search", methods=['GET', 'POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        search_field = form.search_by.data
        if search_field == 'book':
            books = db.session.query(Book, BookInLibrary).join(Book).filter_by(bookName=form.keyword.data)
            return render_template('books.html', books=books)
        elif search_field == 'author':
            books = db.session.query(Book, BookInLibrary).join(Book).filter_by(authorName=form.keyword.data)
            return render_template('books.html', books=books)
        elif search_field == 'library':
            books = db.session.query(Book, BookInLibrary).join(BookInLibrary).filter_by(library_name=form.keyword.data)
            return render_template('books.html', books=books)
    if form.errors != {}:
        for error in form.errors.values():
            flash(f'Error searching: {error}')
    return render_template('search.html', title='Search', form=form)


@app.route("/libraries")
def libraries():
    lb = Library.query.all()
    return render_template('libraries.html', libraries=lb)


@app.route("/about")
def about():
    # In 'about' template, we have an if statement for the title.
    # If we pass an argument here it will show on the website as written in the template.
    return render_template('about.html', title='About')


# Creating a route for the forms to see how they get converted to HTML.
@app.route("/register", methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        member1 = Member.query.filter_by(id=form.id.data).first()
        if member1 is None:
            hashed_pw = generate_password_hash(form.password.data, "sha256")
            member1 = Member(id=form.id.data,
                             firstName=form.firstName.data,
                             lastName=form.lastName.data,
                             email=form.email.data,
                             password_hash=hashed_pw)
            db.session.add(member1)
            db.session.commit()
            login_user(member1)
            flash(f'Member Added {form.email.data}', 'success')
            return redirect(url_for('register_to_library'))
    if form.errors != {}:
        for error in form.errors.values():
            flash(f'Error creating user: {error}')
    return render_template('register.html', title='Register', form=form)


@app.route("/registerToLibrary", methods=['GET', 'POST'])
def register_to_library():
    form = RegisterToLibraryForm()
    if form.validate_on_submit():
        # membership1 = Membership.query.filter_by()
        flash(f'Successfully registered to {form.library.data} library!', 'success')
        return redirect(url_for('home'))

    return render_template('registerToLibrary.html', title='Register To Library', form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)


if __name__ == '__main__':
    app.run(debug=True)

