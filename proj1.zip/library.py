# To use templates we are importing render_templates
from flask import Flask, render_template, url_for, flash, redirect
from forms import RegistrationForm, LoginForm, SearchForm
from flask_sqlalchemy import SQLAlchemy
from models import Member, Library, Membership, Genre, Book, LoanedBook, BookInLibrary, db, app, RegisterToLibraryForm
from datetime import datetime

posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog post 1',
        'content': 'First post content',
        'date_posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog post 2',
        'content': 'Second post content',
        'date_posted': 'April 21, 2018'
    }
]


@app.route("/")
@app.route("/home")
def home():
    # Instead of putting all the html code in the py file,
    # we can call any template with this command.
    # posts - passing argument with posts data to have access in the template
    return render_template('home.html', posts=posts)


@app.route("/search", methods=['GET', 'POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        flash(f'Searching for {form.keyword.data} in {form.search_by.data}', 'success')
        return redirect(url_for('home'))
    if form.errors != {}:
        for error in form.errors.values():
            flash(f'Error creating user: {error}')
    return render_template('search.html', title='Search', form=form)


@app.route("/libraries")
def libraries():
    lb = Library.query.all()
    return render_template('libraries.html', libraries=lb)


@app.route("/about")
def about():
    # In 'about' template, we have an if statement for the title.
    # If we pass an argument here it will show on the website as written in the template.
    return render_template('about.html', title='About')


# Creating a route for the forms to see how they get converted to HTML.
@app.route("/register", methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():  # This tells if the form validated when it was submitted
        # Flash message in flask is an easy way to send a one-time alert
        # Bootstrap has different alert styles for successes and warnings, so we pass the category argument we want.
        # flash(f'Account created for {form.email.data}!', 'success')
        member1 = Member(id=form.id.data,
                         firstName=form.firstName.data,
                         lastName=form.lastName.data,
                         email=form.email.data,
                         password=form.password.data)
        db.session.add(member1)
        db.session.commit()
        return redirect(url_for('register_to_library'))
    if form.errors != {}:
        for error in form.errors.values():
            flash(f'Error creating user: {error}')
    return render_template('register.html', title='Register', form=form)


@app.route("/registerToLibrary", methods=['GET', 'POST'])
def register_to_library():
    form = RegisterToLibraryForm()
    if form.validate_on_submit():
        flash(f'Successfully registered to {form.library.data} library!', 'success')
        return redirect(url_for('home'))

    return render_template('registerToLibrary.html', title='Register To Library', form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)


if __name__ == '__main__':
    app.run(debug=True)

